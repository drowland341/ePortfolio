package com.example.inventoryapp;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.textfield.TextInputEditText;

public class InventoryActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;
    private DatabaseHelper dbHelper;
    private RecyclerView inventoryRecyclerView;
    private InventoryAdapter adapter;
    private boolean smsPermissionGranted = false;
    private TextInputEditText searchInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);
        
        // Initialize RecyclerView
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        if (inventoryRecyclerView != null) {
            inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        }

        // Request SMS permissions
        requestSmsPermission();

        // Initialize buttons
        Button addButton = findViewById(R.id.addButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        Button updateQuantityButton = findViewById(R.id.updateQuantityButton);

        if (addButton != null) {
            addButton.setOnClickListener(v -> showAddItemDialog());
        }
        if (deleteButton != null) {
            deleteButton.setOnClickListener(v -> showRemoveItemDialog());
        }
        if (updateQuantityButton != null) {
            updateQuantityButton.setOnClickListener(v -> showUpdateItemDialog());
        }

        // Initialize search
        searchInput = findViewById(R.id.searchInput);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchInventory(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Load initial inventory data
        loadInventoryData();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Show explanation if needed
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, 
                    Manifest.permission.SEND_SMS)) {
                new AlertDialog.Builder(this)
                    .setTitle("SMS Permission Needed")
                    .setMessage("This permission is needed to send low stock alerts. The app will still work without it.")
                    .setPositiveButton("OK", (dialog, which) -> {
                        requestPermissions();
                    })
                    .create()
                    .show();
            } else {
                requestPermissions();
            }
        } else {
            smsPermissionGranted = true;
        }
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            smsPermissionGranted = grantResults.length > 0 
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void sendLowStockAlert(String itemName, int quantity) {
        if (smsPermissionGranted) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String message = "Low stock alert: " + itemName + " (Quantity: " + quantity + ")";
                smsManager.sendTextMessage("1234567890", null, message, null, null);
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);
        
        EditText itemNameInput = dialogView.findViewById(R.id.itemNameInput);
        EditText quantityInput = dialogView.findViewById(R.id.quantityInput);
        EditText thresholdInput = dialogView.findViewById(R.id.thresholdInput);

        builder.setView(dialogView)
                .setTitle("Add New Item")
                .setPositiveButton("Add", (dialog, id) -> {
                    try {
                        String itemName = itemNameInput.getText().toString().trim();
                        if (TextUtils.isEmpty(itemName)) {
                            Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        int quantity = Integer.parseInt(quantityInput.getText().toString().trim());
                        int threshold = Integer.parseInt(thresholdInput.getText().toString().trim());
                        addInventoryItem(itemName, quantity, threshold);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

        builder.create().show();
    }

    private void showRemoveItemDialog() {
        // Get current items
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
            DatabaseHelper.TABLE_INVENTORY,
            new String[]{DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_ITEM_NAME},
            null,
            null,
            null,
            null,
            null
        );

        if (cursor != null && cursor.getCount() > 0) {
            StringBuilder message = new StringBuilder("Current Items:\n\n");
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                message.append("ID: ").append(id).append(" - ").append(name).append("\n");
            }
            cursor.close();

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            LayoutInflater inflater = getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_remove_item, null);
            
            EditText itemIdInput = dialogView.findViewById(R.id.itemIdInput);

            builder.setView(dialogView)
                    .setTitle("Remove Item")
                    .setMessage(message.toString())
                    .setPositiveButton("Remove", (dialog, id) -> {
                        try {
                            int itemId = Integer.parseInt(itemIdInput.getText().toString().trim());
                            removeInventoryItem(itemId);
                        } catch (NumberFormatException e) {
                            Toast.makeText(this, "Please enter a valid ID", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

            builder.create().show();
        } else {
            Toast.makeText(this, "No items to remove", Toast.LENGTH_SHORT).show();
        }
    }

    private void showUpdateItemDialog() {
        // Get current items
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
            DatabaseHelper.TABLE_INVENTORY,
            new String[]{DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_ITEM_NAME, DatabaseHelper.COLUMN_QUANTITY},
            null,
            null,
            null,
            null,
            null
        );

        if (cursor != null && cursor.getCount() > 0) {
            StringBuilder message = new StringBuilder("Current Items:\n\n");
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY));
                message.append("ID: ").append(id).append(" - ").append(name)
                       .append(" (Quantity: ").append(quantity).append(")\n");
            }
            cursor.close();

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            LayoutInflater inflater = getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_update_item, null);
            
            EditText itemIdInput = dialogView.findViewById(R.id.itemIdInput);
            EditText newQuantityInput = dialogView.findViewById(R.id.newQuantityInput);

            builder.setView(dialogView)
                    .setTitle("Update Item")
                    .setMessage(message.toString())
                    .setPositiveButton("Update", (dialog, id) -> {
                        try {
                            int itemId = Integer.parseInt(itemIdInput.getText().toString().trim());
                            int newQuantity = Integer.parseInt(newQuantityInput.getText().toString().trim());
                            updateInventoryItem(itemId, newQuantity);
                        } catch (NumberFormatException e) {
                            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

            builder.create().show();
        } else {
            Toast.makeText(this, "No items to update", Toast.LENGTH_SHORT).show();
        }
    }

    private void addInventoryItem(String itemName, int quantity, int threshold) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);
        values.put(DatabaseHelper.COLUMN_THRESHOLD, threshold);

        long newRowId = db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
        if (newRowId != -1) {
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
            loadInventoryData();
            
            if (quantity <= threshold) {
                sendLowStockAlert(itemName, quantity);
            }
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }

    private void removeInventoryItem(int itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(itemId) };

        int deletedRows = db.delete(DatabaseHelper.TABLE_INVENTORY, selection, selectionArgs);
        if (deletedRows > 0) {
            Toast.makeText(this, "Item removed successfully", Toast.LENGTH_SHORT).show();
            loadInventoryData();
        } else {
            Toast.makeText(this, "Error removing item", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateInventoryItem(int itemId, int newQuantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_QUANTITY, newQuantity);

        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(itemId) };

        int updatedRows = db.update(DatabaseHelper.TABLE_INVENTORY, values, selection, selectionArgs);
        if (updatedRows > 0) {
            Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
            loadInventoryData();
            
            // Check if we need to send a low stock alert
            Cursor cursor = db.query(
                DatabaseHelper.TABLE_INVENTORY,
                new String[]{DatabaseHelper.COLUMN_ITEM_NAME, DatabaseHelper.COLUMN_THRESHOLD},
                selection,
                selectionArgs,
                null,
                null,
                null
            );
            
            if (cursor != null && cursor.moveToFirst()) {
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_THRESHOLD));
                if (newQuantity <= threshold) {
                    sendLowStockAlert(itemName, newQuantity);
                }
                cursor.close();
            }
        } else {
            Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadInventoryData() {
        searchInventory("");  // Load all items
    }

    private void searchInventory(String query) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String selection = "";
        String[] selectionArgs = null;

        if (!query.isEmpty()) {
            selection = DatabaseHelper.COLUMN_ITEM_NAME + " LIKE ?";
            selectionArgs = new String[]{"%" + query + "%"};
        }

        Cursor cursor = db.query(
            DatabaseHelper.TABLE_INVENTORY,
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        );

        if (inventoryRecyclerView != null) {
            adapter = new InventoryAdapter(this, cursor);
            inventoryRecyclerView.setAdapter(adapter);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
