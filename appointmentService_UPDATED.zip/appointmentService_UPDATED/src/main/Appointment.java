package main;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public final class Appointment {
    private final String appointmentID;
    private final LocalDateTime appointmentDate;
    private String description;

    // Date formatter for logging/debugging
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    //  **Constructor that matches the test cases**
    public Appointment(String appointmentID, LocalDateTime appointmentDate, String description) {
        if (appointmentID == null || appointmentID.trim().isEmpty() || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID: Must be non-null and up to 10 characters.");
        }
        if (appointmentDate == null || appointmentDate.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Invalid appointment date: Cannot be null or in the past.");
        }
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description: Must be non-null and up to 50 characters.");
        }

        this.appointmentID = appointmentID;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getters
    public String getAppointmentID() {
        return appointmentID;
    }

    public LocalDateTime getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    // **Fix: Rename "setDescription" to "updateDescription" for consistency**
    public void updateDescription(String newDescription) {
        if (newDescription == null || newDescription.trim().isEmpty() || newDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid description: Must be non-null and up to 50 characters.");
        }
        this.description = newDescription;
    }

    //  **Fix: Correct the equals method**
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Appointment)) return false;
        Appointment that = (Appointment) obj;
        return Objects.equals(appointmentID, that.appointmentID) &&
               Objects.equals(appointmentDate, that.appointmentDate) &&
               Objects.equals(description, that.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentID, appointmentDate, description);
    }

    @Override
    public String toString() {
        return "Appointment{" +
               "ID='" + appointmentID + '\'' +
               ", Date=" + appointmentDate.format(DATE_FORMATTER) +
               ", Description='" + description + '\'' +
               '}';
    }
}
