package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import main.Contact;

public class ContactTest {

    @Test
    public void testContactCreation() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        assertAll("contact",
                () -> assertEquals("1234567890", contact.getContactID()),
                () -> assertEquals("Tony", contact.getFirstName()),
                () -> assertEquals("Stark", contact.getLastName()),
                () -> assertEquals("0123456789", contact.getPhone()),
                () -> assertEquals("12340 Malibu Point", contact.getAddress()));
    }

    @Test
    public void testContactIDNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Tony", "Stark", "0123456789", "12340 Malibu Point");
        });
        assertEquals("Invalid contact ID", exception.getMessage());
    }

    @Test
    public void testFirstNameNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", null, "Stark", "0123456789", "12340 Malibu Point");
        });
        assertEquals("Invalid first name", exception.getMessage());
    }

    @Test
    public void testLastNameNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Tony", null, "0123456789", "12340 Malibu Point");
        });
        assertEquals("Invalid last name", exception.getMessage());
    }

    @Test
    public void testPhoneNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Tony", "Stark", null, "12340 Malibu Point");
        });
        assertEquals("Invalid phone number", exception.getMessage());
    }

    @Test
    public void testPhoneWrongLength() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Tony", "Stark", "12345", "12340 Malibu Point");
        });
        assertEquals("Invalid phone number", exception.getMessage());
    }

    @Test
    public void testAddressNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Tony", "Stark", "0123456789", null);
        });
        assertEquals("Invalid address", exception.getMessage());
    }

    @Test
    public void testAddressTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Tony", "Stark", "0123456789", "This address is way too long for the limit");
        });
        assertEquals("Invalid address", exception.getMessage());
    }

    @Test
    public void testValidSetters() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");

        contact.setFirstName("Steve");
        contact.setLastName("Rogers");
        contact.setPhone("9876543210");
        contact.setAddress("Brooklyn");

        assertAll("Updated Contact",
                () -> assertEquals("Steve", contact.getFirstName()),
                () -> assertEquals("Rogers", contact.getLastName()),
                () -> assertEquals("9876543210", contact.getPhone()),
                () -> assertEquals("Brooklyn", contact.getAddress()));
    }

    @Test
    public void testSetFirstNameInvalid() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
        assertEquals("Invalid first name", exception.getMessage());
    }

    @Test
    public void testSetLastNameInvalid() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
        assertEquals("Invalid last name", exception.getMessage());
    }

    @Test
    public void testSetPhoneInvalid() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("1234");
        });
        assertEquals("Invalid phone number", exception.getMessage());
    }

    @Test
    public void testSetAddressInvalid() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });
        assertEquals("Invalid address", exception.getMessage());
    }
}
