package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import main.Appointment;
import java.time.LocalDateTime;

public class AppointmentTest {

    private LocalDateTime futureDate;

    @BeforeEach
    public void setUp() {
        futureDate = LocalDateTime.now().plusDays(1); // Ensures future date for valid appointments
    }

    //  **Test valid appointment creation**
    @Test
    public void testAppointmentCreation() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Routine checkup");
        assertAll("appointment",
                () -> assertEquals("1234567890", appointment.getAppointmentID()),
                () -> assertEquals(futureDate, appointment.getAppointmentDate()),
                () -> assertEquals("Routine checkup", appointment.getDescription()));
    }

    //  **Test invalid appointment ID (null)**
    @Test
    public void testAppointmentIDNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Routine checkup");
        });
        assertEquals("Invalid appointment ID: Must be non-null and up to 10 characters.", exception.getMessage());
    }

    //  **Test invalid appointment ID (too long)**
    @Test
    public void testAppointmentIDTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Routine checkup"); // 11 characters
        });
        assertEquals("Invalid appointment ID: Must be non-null and up to 10 characters.", exception.getMessage());
    }

    //  **Test invalid appointment date (null)**
    @Test
    public void testAppointmentDateNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", null, "Routine checkup");
        });
        assertEquals("Invalid appointment date: Cannot be null or in the past.", exception.getMessage());
    }

    //  **Test invalid appointment date (past date)**
    @Test
    public void testAppointmentDateNotPast() {
        LocalDateTime pastDate = LocalDateTime.now().minusDays(1);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Routine checkup");
        });
        assertEquals("Invalid appointment date: Cannot be null or in the past.", exception.getMessage());
    }

    //  **Test invalid description (null)**
    @Test
    public void testDescriptionNotNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, null);
        });
        assertEquals("Invalid description: Must be non-null and up to 50 characters.", exception.getMessage());
    }

    //  **Test invalid description (too long)**
    @Test
    public void testDescriptionTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, "This is an excessively long appointment description that exceeds fifty characters.");
        });
        assertEquals("Invalid description: Must be non-null and up to 50 characters.", exception.getMessage());
    }

    //  **Test updating description with valid value**
    @Test
    public void testUpdateDescriptionValid() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Initial checkup");
        appointment.updateDescription("Follow-up checkup");
        assertEquals("Follow-up checkup", appointment.getDescription());
    }

    //  **Test updating description with invalid value (null)**
    @Test
    public void testUpdateDescriptionInvalidNull() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Initial checkup");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.updateDescription(null);
        });
        assertEquals("Invalid description: Must be non-null and up to 50 characters.", exception.getMessage());
    }

    //  **Test updating description with invalid value (too long)**
    @Test
    public void testUpdateDescriptionInvalidTooLong() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Initial checkup");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.updateDescription("This is an excessively long appointment description that exceeds fifty characters.");
        });
        assertEquals("Invalid description: Must be non-null and up to 50 characters.", exception.getMessage());
    }

    //  **Test equals() method (valid comparison)**
    @Test
    public void testEqualsMethod() {
        Appointment appointment1 = new Appointment("1234567890", futureDate, "Routine checkup");
        Appointment appointment2 = new Appointment("1234567890", futureDate, "Routine checkup");
        assertEquals(appointment1, appointment2);
    }

    //  **Test equals() method with null**
    @Test
    public void testEqualsMethodWithNull() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Routine checkup");
        assertFalse(appointment.equals(null));
    }

    //  **Test equals() method with different object type**
    @Test
    public void testEqualsMethodWithDifferentObject() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Routine checkup");
        String randomString = "Not an appointment";
        assertFalse(appointment.equals(randomString));
    }

    //  **Test hashCode() method**
    @Test
    public void testHashCodeMethod() {
        Appointment appointment1 = new Appointment("1234567890", futureDate, "Routine checkup");
        Appointment appointment2 = new Appointment("1234567890", futureDate, "Routine checkup");
        assertEquals(appointment1.hashCode(), appointment2.hashCode());
    }

    // ✅ **Test toString() method**
    @Test
    public void testToStringMethod() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Routine checkup");
        String expectedOutput = "Appointment{ID='1234567890', Date=" + futureDate + ", Description='Routine checkup'}";
        assertEquals(expectedOutput, appointment.toString());
    }
}
