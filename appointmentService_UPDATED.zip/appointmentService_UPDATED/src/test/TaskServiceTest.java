package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Task;
import main.TaskService;

class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1234567890"));
    }

    @Test
    public void testAddDuplicateTask() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task);
        });
        assertEquals("Task ID already exists", exception.getMessage());
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.deleteTask("1234567890");
        assertNull(taskService.getTask("1234567890"));
    }

    @Test
    public void testDeleteNonExistentTask() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask("9999999999");
        });
        assertEquals("Task ID does not exist", exception.getMessage());
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.updateTask("1234567890", "Updated Name", "Updated Description");
        Task updatedTask = taskService.getTask("1234567890");
        assertAll("updatedTask",
                () -> assertEquals("Updated Name", updatedTask.getName()),
                () -> assertEquals("Updated Description", updatedTask.getDescription()));
    }

    @Test
    public void testUpdateNonExistentTask() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("9999999999", "New Name", "New Description");
        });
        assertEquals("Task ID does not exist", exception.getMessage());
    }

    @Test
    public void testUpdateTaskWithInvalidValues() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);

        // All invalid updates: name too long, description too long, and nulls
        taskService.updateTask("1234567890", null, null);
        taskService.updateTask("1234567890", "ThisNameIsWayTooLongToBeValid", "ThisDescriptionIsAlsoWayTooLongToBeStoredCorrectlySinceItExceedsTheAllowedLimit");

        Task unchangedTask = taskService.getTask("1234567890");

        assertAll("unchangedTask",
                () -> assertEquals("Task Name", unchangedTask.getName()),
                () -> assertEquals("Task Description", unchangedTask.getDescription()));
    }
}
