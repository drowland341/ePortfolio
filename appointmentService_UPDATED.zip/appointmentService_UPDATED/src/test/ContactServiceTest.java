package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Contact;
import main.ContactService;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("1234567890"));
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        contactService.addContact(contact);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact);
        });
        assertEquals("Contact ID already exists", exception.getMessage());
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        contactService.addContact(contact);
        contactService.deleteContact("1234567890");
        assertNull(contactService.getContact("1234567890"));
    }

    @Test
    public void testDeleteNonExistentContact() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("9999999999");
        });
        assertEquals("Contact ID does not exist", exception.getMessage());
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        contactService.addContact(contact);
        contactService.updateContact("1234567890", "Peter", "Parker", "0987654321", "20 Ingram Street");
        Contact updatedContact = contactService.getContact("1234567890");

        assertAll("updatedContact",
                () -> assertEquals("Peter", updatedContact.getFirstName()),
                () -> assertEquals("Parker", updatedContact.getLastName()),
                () -> assertEquals("0987654321", updatedContact.getPhone()),
                () -> assertEquals("20 Ingram Street", updatedContact.getAddress()));
    }

    @Test
    public void testUpdateNonExistentContact() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("9999999999", "Bruce", "Wayne", "1112223333", "Wayne Manor");
        });
        assertEquals("Contact ID does not exist", exception.getMessage());
    }

    @Test
    public void testUpdateContactWithInvalidValues() {
        Contact contact = new Contact("1234567890", "Tony", "Stark", "0123456789", "12340 Malibu Point");
        contactService.addContact(contact);

        // This update should be ignored since all values are invalid (too long, null, or wrong format)
        contactService.updateContact("1234567890", null, "VeryLongLastNameExceedingTenChars", "short", "This address is definitely longer than thirty characters long");

        Contact unchangedContact = contactService.getContact("1234567890");

        // All fields should remain unchanged
        assertAll("unchangedContact",
                () -> assertEquals("Tony", unchangedContact.getFirstName()),
                () -> assertEquals("Stark", unchangedContact.getLastName()),
                () -> assertEquals("0123456789", unchangedContact.getPhone()),
                () -> assertEquals("12340 Malibu Point", unchangedContact.getAddress()));
    }
}
