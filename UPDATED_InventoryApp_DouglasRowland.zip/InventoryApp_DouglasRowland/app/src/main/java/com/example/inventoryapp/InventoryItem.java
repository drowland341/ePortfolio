package com.example.inventoryapp;

public class InventoryItem {
    private int id;
    private String itemName;
    private int quantity;
    private int threshold;

    public InventoryItem(int id, String itemName, int quantity, int threshold) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.threshold = threshold;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getThreshold() {
        return threshold;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setThreshold(int threshold) {
        this.threshold = threshold;
    }
}
