package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.chip.ChipGroup;

public class SortActivity extends AppCompatActivity {
    public static final String EXTRA_SORT_TYPE = "sort_type";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sort);

        // Enable back button in action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Sort & Filter");

        ChipGroup sortChipGroup = findViewById(R.id.sortChipGroup);
        Button applyButton = findViewById(R.id.applyButton);

        applyButton.setOnClickListener(v -> {
            int checkedId = sortChipGroup.getCheckedChipId();
            String sortType = "name"; // default

            if (checkedId == R.id.chipName) {
                sortType = "name";
            } else if (checkedId == R.id.chipQuantityHigh) {
                sortType = "quantity_high";
            } else if (checkedId == R.id.chipQuantityLow) {
                sortType = "quantity_low";
            } else if (checkedId == R.id.chipLowStock) {
                sortType = "low_stock";
            } else if (checkedId == R.id.chipOfficeSupplies) {
                sortType = "office";
            } else if (checkedId == R.id.chipWarehouse) {
                sortType = "warehouse";
            }

            Intent resultIntent = new Intent();
            resultIntent.putExtra(EXTRA_SORT_TYPE, sortType);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 