package com.example.inventoryapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.ArrayList;

/**
 * Updated InventoryAdapter that uses a List<InventoryItem> instead of Cursor.
 * Adds support for clicking an item to view more details in ItemDetailActivity.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private Context context;
    private List<InventoryItem> itemList;

    public InventoryAdapter(Context context, List<InventoryItem> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.inventory_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.idText.setText("ID: " + item.getId());
        holder.nameText.setText(item.getItemName());
        holder.quantityText.setText("Quantity: " + item.getQuantity());

        // Add click listener to open ItemDetailActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ItemDetailActivity.class);
            intent.putExtra("item_id", item.getId());
            intent.putExtra("item_name", item.getItemName());
            intent.putExtra("item_quantity", item.getQuantity());
            intent.putExtra("item_threshold", item.getThreshold());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public void updateList(List<InventoryItem> newList) {
        this.itemList = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView idText;
        public TextView nameText;
        public TextView quantityText;

        public ViewHolder(View itemView) {
            super(itemView);
            idText = itemView.findViewById(R.id.itemId);
            nameText = itemView.findViewById(R.id.itemName);
            quantityText = itemView.findViewById(R.id.itemQuantity);
        }
    }
}
