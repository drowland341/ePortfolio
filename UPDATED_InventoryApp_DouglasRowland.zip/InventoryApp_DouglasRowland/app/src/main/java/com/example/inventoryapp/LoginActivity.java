package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private EditText usernameInput;
    private EditText passwordInput;

    // Global static flag to indicate if current user is admin
    public static boolean isAdmin = false;

    // Add these constants at the top of the class
    private static final String ADMIN_PASSWORD_HASH = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"; // hash of "admin"

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_login);

            dbHelper = new DatabaseHelper(this);

            // Bind views
            usernameInput = findViewById(R.id.usernameInput);
            passwordInput = findViewById(R.id.passwordInput);
            Button loginButton = findViewById(R.id.loginButton);
            Button registerButton = findViewById(R.id.registerButton);
            Button adminButton = findViewById(R.id.adminLoginButton); // New Admin login button

            // Handle button actions
            if (loginButton != null && registerButton != null && adminButton != null) {
                // Regular user login
                loginButton.setOnClickListener(v -> attemptLogin(false));

                // Register new user
                registerButton.setOnClickListener(v -> attemptRegister());

                // Admin login bypass
                adminButton.setOnClickListener(v -> showAdminLoginDialog());
            } else {
                Toast.makeText(this, "Error initializing buttons", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error starting app: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Handles login for regular users.
     * Admin flag only true if triggered from admin button.
     */
    private void attemptLogin(boolean isAdminAttempt) {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (validateCredentials(username, password)) {
            isAdmin = isAdminAttempt; // This will be false for regular login
            startActivity(new Intent(this, InventoryActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Registers a new user by saving username and password.
     */
    private void attemptRegister() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {DatabaseHelper.COLUMN_USERNAME};
        String selection = DatabaseHelper.COLUMN_USERNAME + "=?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns, selection,
                selectionArgs, null, null, null);

        if (cursor.getCount() > 0) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            cursor.close();
            return;
        }
        cursor.close();

        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, username);
        values.put(DatabaseHelper.COLUMN_PASSWORD, password);

        long result = db.insert(DatabaseHelper.TABLE_USERS, null, values);
        if (result != -1) {
            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, InventoryActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Validates user credentials against stored users in the database.
     */
    private boolean validateCredentials(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {DatabaseHelper.COLUMN_USERNAME};
        String selection = DatabaseHelper.COLUMN_USERNAME + "=? AND " +
                DatabaseHelper.COLUMN_PASSWORD + "=?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns, selection,
                selectionArgs, null, null, null);

        boolean result = cursor.getCount() > 0;
        cursor.close();
        return result;
    }

    // Add this new method
    private void showAdminLoginDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Admin Authentication");
        
        // Inflate the custom layout
        View view = getLayoutInflater().inflate(R.layout.dialog_admin_login, null);
        EditText passwordInput = view.findViewById(R.id.adminPasswordInput);
        builder.setView(view);

        builder.setPositiveButton("Login", (dialog, which) -> {
            String password = passwordInput.getText().toString();
            String hashedPassword = hashPassword(password);
            if (hashedPassword.equals(ADMIN_PASSWORD_HASH)) {
                isAdmin = true;
                Toast.makeText(this, "Logged in as admin", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, InventoryActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid admin password", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Add this method for hashing
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
