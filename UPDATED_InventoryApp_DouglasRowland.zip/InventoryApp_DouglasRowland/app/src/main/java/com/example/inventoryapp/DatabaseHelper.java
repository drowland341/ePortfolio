package com.example.inventoryapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "InventoryDB";
    private static final int DATABASE_VERSION = 2; // Incremented DB version to apply changes

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_THRESHOLD = "threshold";

    // Logs table
    public static final String TABLE_LOGS = "logs";
    public static final String COLUMN_LOG_ID = "id";
    public static final String COLUMN_LOG_ACTION = "action";       // "Add", "Update", "Delete"
    public static final String COLUMN_LOG_ITEM_NAME = "item_name";
    public static final String COLUMN_LOG_QUANTITY = "quantity";
    public static final String COLUMN_LOG_TIMESTAMP = "timestamp";

    // Create logs table query
    private static final String CREATE_LOGS_TABLE = "CREATE TABLE " + TABLE_LOGS + " (" +
            COLUMN_LOG_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_LOG_ACTION + " TEXT NOT NULL, " +
            COLUMN_LOG_ITEM_NAME + " TEXT NOT NULL, " +
            COLUMN_LOG_QUANTITY + " INTEGER, " +
            COLUMN_LOG_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // Users table
            String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                    + COLUMN_USERNAME + " TEXT PRIMARY KEY,"
                    + COLUMN_PASSWORD + " TEXT" + ")";

            // Inventory table
            String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_ITEM_NAME + " TEXT,"
                    + COLUMN_QUANTITY + " INTEGER,"
                    + COLUMN_THRESHOLD + " INTEGER" + ")";

            // Logs table
            db.execSQL(CREATE_LOGS_TABLE);

            db.execSQL(CREATE_USERS_TABLE);
            db.execSQL(CREATE_INVENTORY_TABLE);
            Log.i("DatabaseHelper", "All tables created successfully");
        } catch (android.database.SQLException e) {
            Log.e("DatabaseHelper", "Error creating tables: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i("DatabaseHelper", "Upgrading database from " + oldVersion + " to " + newVersion);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGS); // Drop logs table if it exists
        onCreate(db);
    }
}
