package com.example.inventoryapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Objects;

public class LogViewerActivity extends AppCompatActivity {
    private static final String TAG = "LogViewerActivity";
    private DatabaseHelper dbHelper;
    private TextView logTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_viewer);

        // Enable back button in action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Activity Logs");
        }

        dbHelper = new DatabaseHelper(this);
        logTextView = findViewById(R.id.logTextView);

        displayLogs();
    }

    private void displayLogs() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        StringBuilder logBuilder = new StringBuilder();

        try {
            Cursor cursor = db.query(
                DatabaseHelper.TABLE_LOGS,
                null,
                null,
                null,
                null,
                null,
                DatabaseHelper.COLUMN_LOG_TIMESTAMP + " DESC" // Order by timestamp
            );

            if (cursor != null) {
                int count = cursor.getCount();
                Log.d(TAG, "Total log entries found: " + count);
                
                if (cursor.moveToFirst()) {
                    do {
                        appendLogEntry(cursor, logBuilder);
                    } while (cursor.moveToNext());
                } else {
                    logBuilder.append("No logs available.");
                }
                cursor.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error displaying logs", e);
            logBuilder.append("Error loading logs: ").append(e.getMessage());
        }

        logTextView.setText(logBuilder.toString());
    }

    private void appendLogEntry(Cursor cursor, StringBuilder logBuilder) {
        try {
            String timestamp = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOG_TIMESTAMP));
            String action = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOG_ACTION));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOG_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOG_QUANTITY));

            // Safer action parsing
            String userType = "System";
            String actionType = action;
            
            if (action != null && action.contains(" ")) {
                String[] actionParts = action.split(" ", 2);
                if (actionParts.length == 2) {
                    userType = actionParts[0];
                    actionType = actionParts[1];
                }
            }

            // Format timestamp if available
            if (timestamp != null) {
                logBuilder.append("Time: ").append(timestamp).append("\n");
            }
            
            logBuilder.append("User: ").append(userType).append("\n")
                    .append("Action: ").append(actionType).append("\n")
                    .append("Item: ").append(itemName != null ? itemName : "N/A");

            // Show quantity based on action type
            if (Objects.equals(actionType, "Add") || Objects.equals(actionType, "Update")) {
                logBuilder.append("\nQuantity: ").append(quantity);
            } else if (Objects.equals(actionType, "Delete")) {
                logBuilder.append("\nItem Deleted");
            } else if (Objects.equals(actionType, "Clear All")) {
                logBuilder.append("\nAll items cleared");
            } else if (action != null && action.contains("Generated test data")) {
                logBuilder.append("\nTest data generated");
            }
            
            logBuilder.append("\n----------------------------------------\n");
        } catch (Exception e) {
            Log.e(TAG, "Error appending log entry", e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayLogs();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}

