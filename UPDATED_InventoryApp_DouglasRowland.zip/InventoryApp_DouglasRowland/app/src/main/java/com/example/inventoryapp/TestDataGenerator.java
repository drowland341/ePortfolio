package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import java.util.Random;

public class TestDataGenerator {
    private final DatabaseHelper dbHelper;
    private final Random random = new Random();

    // Arrays of sample items
    private final String[] officeSupplies = {
        "Ballpoint Pens", "Staplers", "Paper Clips", "Notebooks", "Sticky Notes",
        "Highlighters", "Folders", "Binders", "Printer Paper", "Envelopes",
        "Pencils", "Erasers", "Markers", "Tape Dispensers", "Scissors",
        "Calculator", "Rubber Bands", "Index Cards", "File Labels", "Correction Fluid"
    };

    private final String[] warehouseItems = {
        "Shipping Boxes", "Packing Tape", "Bubble Wrap", "Pallets", "Safety Gloves",
        "Hard Hats", "Utility Knives", "Dollies", "Storage Bins", "Shelving Units",
        "Work Lights", "Extension Cords", "First Aid Kits", "Safety Vests", "Caution Signs",
        "Hand Trucks", "Zip Ties", "Shrink Wrap", "Label Makers", "Tool Sets"
    };

    public TestDataGenerator(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void generateTestData() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            // Clear existing data
            db.delete(DatabaseHelper.TABLE_INVENTORY, null, null);
            
            // Log the clear action
            ContentValues logValues = new ContentValues();
            logValues.put(DatabaseHelper.COLUMN_LOG_ACTION, "Admin Clear All");
            logValues.put(DatabaseHelper.COLUMN_LOG_ITEM_NAME, "All Items");
            logValues.put(DatabaseHelper.COLUMN_LOG_QUANTITY, 0);
            db.insert(DatabaseHelper.TABLE_LOGS, null, logValues);

            // Generate office supplies
            for (String item : officeSupplies) {
                int quantity = random.nextInt(100) + 1;
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_ITEM_NAME, item);
                values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);
                values.put(DatabaseHelper.COLUMN_THRESHOLD, random.nextInt(20) + 5);
                db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
                logAction(db, "Test Data", "Added " + item, quantity);
            }

            // Generate warehouse items
            for (String item : warehouseItems) {
                int quantity = random.nextInt(50) + 1;
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_ITEM_NAME, item);
                values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);
                values.put(DatabaseHelper.COLUMN_THRESHOLD, random.nextInt(10) + 3);
                db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
                logAction(db, "Test Data", "Added " + item, quantity);
            }

            // Generate additional random combinations
            String[] allItems = new String[officeSupplies.length + warehouseItems.length];
            System.arraycopy(officeSupplies, 0, allItems, 0, officeSupplies.length);
            System.arraycopy(warehouseItems, 0, allItems, officeSupplies.length, warehouseItems.length);

            for (int i = 0; i < 60; i++) {
                String itemName = allItems[random.nextInt(allItems.length)];
                String suffix = " - " + (char)('A' + random.nextInt(3));
                int quantity = random.nextInt(200) + 1;
                
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName + suffix);
                values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);
                values.put(DatabaseHelper.COLUMN_THRESHOLD, random.nextInt(30) + 5);
                db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
                logAction(db, "Test Data", "Added " + itemName + suffix, quantity);
            }

            // Log the test data generation
            logValues = new ContentValues();
            logValues.put(DatabaseHelper.COLUMN_LOG_ACTION, "Admin Generated test data");
            logValues.put(DatabaseHelper.COLUMN_LOG_ITEM_NAME, "Test Data");
            logValues.put(DatabaseHelper.COLUMN_LOG_QUANTITY, 0);
            db.insert(DatabaseHelper.TABLE_LOGS, null, logValues);

        } catch (Exception e) {
            Log.e("TestDataGenerator", "Error generating test data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void logAction(SQLiteDatabase db, String action, String itemName, int quantity) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_LOG_ACTION, action);
        values.put(DatabaseHelper.COLUMN_LOG_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_LOG_QUANTITY, quantity);
        db.insert(DatabaseHelper.TABLE_LOGS, null, values);
    }
} 