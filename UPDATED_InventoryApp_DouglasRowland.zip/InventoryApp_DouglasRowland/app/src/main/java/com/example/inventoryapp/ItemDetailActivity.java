package com.example.inventoryapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_ID = "item_id";
    public static final String EXTRA_ITEM_NAME = "item_name";
    public static final String EXTRA_ITEM_QUANTITY = "item_quantity";
    public static final String EXTRA_ITEM_THRESHOLD = "item_threshold";

    private int id;
    private String name;
    private int quantity;
    private int threshold;

    private TextView nameText;
    private TextView quantityText;
    private TextView thresholdText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        // Bind views
        TextView idText = findViewById(R.id.detailItemId);
        nameText = findViewById(R.id.detailItemName);
        quantityText = findViewById(R.id.detailItemQuantity);
        thresholdText = findViewById(R.id.detailItemThreshold);
        Button editButton = findViewById(R.id.buttonEdit);
        Button deleteButton = findViewById(R.id.buttonDelete);

        // Retrieve data passed via intent
        id = getIntent().getIntExtra(EXTRA_ITEM_ID, -1);
        name = getIntent().getStringExtra(EXTRA_ITEM_NAME);
        quantity = getIntent().getIntExtra(EXTRA_ITEM_QUANTITY, -1);
        threshold = getIntent().getIntExtra(EXTRA_ITEM_THRESHOLD, -1);

        // Populate initial UI
        idText.setText(String.format("ID: %d", id));
        nameText.setText(String.format("Name: %s", name != null ? name : "N/A"));
        quantityText.setText(String.format("Quantity: %d", quantity));
        thresholdText.setText(String.format("Threshold: %d", threshold));

        // Edit Button Logic
        editButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(ItemDetailActivity.this);
            View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_item, null);

            EditText nameInput = dialogView.findViewById(R.id.itemNameInput);
            EditText quantityInput = dialogView.findViewById(R.id.quantityInput);
            EditText thresholdInput = dialogView.findViewById(R.id.thresholdInput);

            nameInput.setText(name);
            quantityInput.setText(String.valueOf(quantity));
            thresholdInput.setText(String.valueOf(threshold));

            builder.setView(dialogView)
                    .setTitle("Edit Item")
                    .setPositiveButton("Save", (dialog, which) -> {
                        try {
                            String newName = nameInput.getText().toString().trim();
                            int newQuantity = Integer.parseInt(quantityInput.getText().toString().trim());
                            int newThreshold = Integer.parseInt(thresholdInput.getText().toString().trim());

                            // Update database
                            DatabaseHelper dbHelper = new DatabaseHelper(this);
                            SQLiteDatabase db = dbHelper.getWritableDatabase();
                            ContentValues values = new ContentValues();
                            values.put(DatabaseHelper.COLUMN_ITEM_NAME, newName);
                            values.put(DatabaseHelper.COLUMN_QUANTITY, newQuantity);
                            values.put(DatabaseHelper.COLUMN_THRESHOLD, newThreshold);

                            int rowsUpdated = db.update(DatabaseHelper.TABLE_INVENTORY, values,
                                    DatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});

                            if (rowsUpdated > 0) {
                                // Update local values and UI
                                name = newName;
                                quantity = newQuantity;
                                threshold = newThreshold;

                                nameText.setText("Name: " + name);
                                quantityText.setText("Quantity: " + quantity);
                                thresholdText.setText("Threshold: " + threshold);

                                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                            }
                        } catch (NumberFormatException e) {
                            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .create()
                    .show();
        });

        // Delete Button Logic
        deleteButton.setOnClickListener(v -> {
            new AlertDialog.Builder(ItemDetailActivity.this)
                    .setTitle("Confirm Deletion")
                    .setMessage("Are you sure you want to delete this item?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        DatabaseHelper dbHelper = new DatabaseHelper(this);
                        SQLiteDatabase db = dbHelper.getWritableDatabase();

                        int deleted = db.delete(DatabaseHelper.TABLE_INVENTORY,
                                DatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});

                        if (deleted > 0) {
                            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                            finish(); // Exit detail view
                        } else {
                            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }
}
