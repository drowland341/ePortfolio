package com.example.inventoryapp;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class InventoryActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;
    private static final int SORT_REQUEST_CODE = 100;
    private static final int MENU_GENERATE_TEST_DATA = 1;
    private DatabaseHelper dbHelper;
    private RecyclerView inventoryRecyclerView;
    private InventoryAdapter adapter;
    private boolean smsPermissionGranted = false;
    private TextInputEditText searchInput;
    private List<InventoryItem> inventoryItemList = new ArrayList<>();
    private boolean testDataGenerated = false;
    private String currentSort = "name"; // Default sort
    private Set<String> officeSupplies = new HashSet<>(Arrays.asList(
        "Ballpoint Pens", "Staplers", "Paper Clips", "Notebooks", "Sticky Notes",
        "Highlighters", "Folders", "Binders", "Printer Paper", "Envelopes",
        "Pencils", "Erasers", "Markers", "Tape Dispensers", "Scissors",
        "Calculator", "Rubber Bands", "Index Cards", "File Labels", "Correction Fluid"
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);
        inventoryItemList = new ArrayList<>();
        
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        if (inventoryRecyclerView != null) {
            inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new InventoryAdapter(this, inventoryItemList);
            inventoryRecyclerView.setAdapter(adapter);
        }

        requestSmsPermission();

        Button addButton = findViewById(R.id.addButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        Button updateQuantityButton = findViewById(R.id.updateQuantityButton);
        Button logsButton = findViewById(R.id.logsButton);
        Button logoutButton = findViewById(R.id.logoutButton);
        Button sortButton = findViewById(R.id.sortButton);

        if (addButton != null) {
            addButton.setOnClickListener(v -> showAddItemDialog());
        }
        if (deleteButton != null) {
            deleteButton.setOnClickListener(v -> showRemoveItemDialog());
        }
        if (updateQuantityButton != null) {
            updateQuantityButton.setOnClickListener(v -> showUpdateItemDialog());
        }

        if (logsButton != null) {
            if (LoginActivity.isAdmin) {
                logsButton.setVisibility(View.VISIBLE);
                logsButton.setOnClickListener(v -> {
                    Intent intent = new Intent(InventoryActivity.this, LogViewerActivity.class);
                    startActivity(intent);
                });
            } else {
                logsButton.setVisibility(View.GONE);
            }
        }

        if (logoutButton != null) {
            logoutButton.setOnClickListener(v -> {
                LoginActivity.isAdmin = false;
                Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(InventoryActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            });
        }

        if (sortButton != null) {
            sortButton.setOnClickListener(v -> {
                Intent intent = new Intent(InventoryActivity.this, SortActivity.class);
                startActivityForResult(intent, SORT_REQUEST_CODE);
            });
        }

        searchInput = findViewById(R.id.searchInput);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchInventory(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        loadInventoryData();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
                new AlertDialog.Builder(this)
                        .setTitle("SMS Permission Needed")
                        .setMessage("This permission is needed to send low stock alerts. The app will still work without it.")
                        .setPositiveButton("OK", (dialog, which) -> requestPermissions())
                        .create()
                        .show();
            } else {
                requestPermissions();
            }
        } else {
            smsPermissionGranted = true;
        }
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            smsPermissionGranted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void sendLowStockAlert(String itemName, int quantity) {
        if (smsPermissionGranted) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String message = "Low stock alert: " + itemName + " (Quantity: " + quantity + ")";
                smsManager.sendTextMessage("+11234567890", null, message, null, null);
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);

        EditText itemNameInput = dialogView.findViewById(R.id.itemNameInput);
        EditText quantityInput = dialogView.findViewById(R.id.quantityInput);
        EditText thresholdInput = dialogView.findViewById(R.id.thresholdInput);

        builder.setView(dialogView)
                .setTitle("Add New Item")
                .setPositiveButton("Add", (dialog, id) -> {
                    try {
                        String itemName = itemNameInput.getText().toString().trim();
                        if (TextUtils.isEmpty(itemName)) {
                            Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        int quantity = Integer.parseInt(quantityInput.getText().toString().trim());
                        int threshold = Integer.parseInt(thresholdInput.getText().toString().trim());
                        addInventoryItem(itemName, quantity, threshold);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

        builder.create().show();
    }

    private void showRemoveItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_remove_item, null);
        EditText itemIdInput = dialogView.findViewById(R.id.itemIdInput);

        builder.setView(dialogView)
                .setTitle("Remove Item")
                .setPositiveButton("Remove", (dialog, id) -> {
                    try {
                        int itemId = Integer.parseInt(itemIdInput.getText().toString().trim());
                        Log.d("InventoryActivity", "Attempting to remove item with ID: " + itemId);
                        removeInventoryItem(itemId);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter a valid ID", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

        builder.create().show();
    }

    private void showUpdateItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_update_item, null);

        EditText itemIdInput = dialogView.findViewById(R.id.itemIdInput);
        EditText newQuantityInput = dialogView.findViewById(R.id.newQuantityInput);

        builder.setView(dialogView)
                .setTitle("Update Item Quantity")
                .setPositiveButton("Update", (dialog, id) -> {
                    try {
                        int itemId = Integer.parseInt(itemIdInput.getText().toString().trim());
                        int newQuantity = Integer.parseInt(newQuantityInput.getText().toString().trim());
                        updateInventoryItem(itemId, newQuantity);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

        builder.create().show();
    }

    private void addInventoryItem(String itemName, int quantity, int threshold) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);
        values.put(DatabaseHelper.COLUMN_THRESHOLD, threshold);

        long newRowId = db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
        if (newRowId != -1) {
            logAction("Add", itemName, quantity);
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
            loadInventoryData();
            if (quantity <= threshold) {
                sendLowStockAlert(itemName, quantity);
            }
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }

    private void removeInventoryItem(int itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        try {
            // First get the item details for logging
            String[] columns = {DatabaseHelper.COLUMN_ITEM_NAME, DatabaseHelper.COLUMN_QUANTITY};
            String selection = DatabaseHelper.COLUMN_ID + "=?";
            String[] selectionArgs = {String.valueOf(itemId)};
            
            Cursor cursor = db.query(
                DatabaseHelper.TABLE_INVENTORY,
                columns,
                selection,
                selectionArgs,
                null, null, null
            );

            if (cursor != null && cursor.moveToFirst()) {
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY));
                cursor.close();
                
                // Delete the item
                int rowsAffected = db.delete(DatabaseHelper.TABLE_INVENTORY, selection, selectionArgs);
                
                if (rowsAffected > 0) {
                    // Log the deletion with the item's details
                    logAction("Delete", itemName, quantity);
                    Toast.makeText(this, "Item removed", Toast.LENGTH_SHORT).show();
                    loadInventoryData();
                }
            }
        } catch (Exception e) {
            Log.e("InventoryActivity", "Error removing item: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateInventoryItem(int itemId, int newQuantity) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
            DatabaseHelper.TABLE_INVENTORY,
            new String[]{DatabaseHelper.COLUMN_ITEM_NAME},
            DatabaseHelper.COLUMN_ID + "=?",
            new String[]{String.valueOf(itemId)},
            null, null, null
        );

        if (cursor != null && cursor.moveToFirst()) {
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
            cursor.close();

            db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_QUANTITY, newQuantity);

            int updatedRows = db.update(DatabaseHelper.TABLE_INVENTORY, values,
                    DatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(itemId)});

            if (updatedRows > 0) {
                logAction("Update", itemName, newQuantity);
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
                loadInventoryData();
            } else {
                Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            if (cursor != null) cursor.close();
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void logAction(String action, String itemName, int quantity) {
        try {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            
            String userType = LoginActivity.isAdmin ? "Admin" : "User";
            String formattedAction = String.format("%s %s", userType, action);
            
            Log.d("InventoryActivity", "Logging action: " + formattedAction);
            Log.d("InventoryActivity", "Item name: " + itemName);
            Log.d("InventoryActivity", "Quantity: " + quantity);
            
            values.put(DatabaseHelper.COLUMN_LOG_ACTION, formattedAction);
            values.put(DatabaseHelper.COLUMN_LOG_ITEM_NAME, itemName);
            values.put(DatabaseHelper.COLUMN_LOG_QUANTITY, quantity);
            
            long result = db.insert(DatabaseHelper.TABLE_LOGS, null, values);
            
            if (result == -1) {
                Log.e("InventoryActivity", "Failed to insert log entry");
            } else {
                Log.d("InventoryActivity", "Successfully logged with ID: " + result);
            }
        } catch (Exception e) {
            Log.e("InventoryActivity", "Error in logAction: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadInventoryData() {
        inventoryItemList = loadInventoryListFromDB();
        if (adapter != null) {
            adapter.updateList(inventoryItemList);
        }
        sortInventory();
    }

    private List<InventoryItem> loadInventoryListFromDB() {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        try {
            Log.d("InventoryActivity", "Loading inventory from database...");
            Cursor cursor = db.query(
                DatabaseHelper.TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                null
            );

            if (cursor != null) {
                Log.d("InventoryActivity", "Cursor count: " + cursor.getCount());
                if (cursor.moveToFirst()) {
                    do {
                        int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                        String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                        int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY));
                        int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_THRESHOLD));

                        InventoryItem item = new InventoryItem(id, itemName, quantity, threshold);
                        itemList.add(item);
                        Log.d("InventoryActivity", "Loaded item: " + itemName + " (ID: " + id + ")");
                    } while (cursor.moveToNext());
                } else {
                    Log.d("InventoryActivity", "No items found in database");
                }
                cursor.close();
            }
        } catch (Exception e) {
            Log.e("InventoryActivity", "Error loading inventory: " + e.getMessage());
            e.printStackTrace();
        }

        Log.d("InventoryActivity", "Total items loaded: " + itemList.size());
        return itemList;
    }

    private void searchInventory(String query) {
        List<InventoryItem> filteredList = new ArrayList<>();
        for (InventoryItem item : inventoryItemList) {
            if (item.getItemName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.updateList(filteredList);
    }

    private void sortInventory() {
        if (inventoryItemList == null) return;
        
        List<InventoryItem> sortedList = new ArrayList<>(inventoryItemList);
        
        switch (currentSort) {
            case "name":
                Collections.sort(sortedList, (a, b) -> 
                    a.getItemName().compareToIgnoreCase(b.getItemName()));
                break;
                
            case "quantity_high":
                Collections.sort(sortedList, (a, b) -> 
                    Integer.compare(b.getQuantity(), a.getQuantity()));
                break;
                
            case "quantity_low":
                Collections.sort(sortedList, (a, b) -> 
                    Integer.compare(a.getQuantity(), b.getQuantity()));
                break;
                
            case "low_stock":
                Collections.sort(sortedList, (a, b) -> {
                    boolean aLow = a.getQuantity() <= a.getThreshold();
                    boolean bLow = b.getQuantity() <= b.getThreshold();
                    if (aLow && !bLow) return -1;
                    if (!aLow && bLow) return 1;
                    return Integer.compare(a.getQuantity(), b.getQuantity());
                });
                break;
                
            case "office":
                sortedList = sortedList.stream()
                    .filter(item -> isOfficeSupply(item.getItemName()))
                    .collect(Collectors.toList());
                break;
                
            case "warehouse":
                sortedList = sortedList.stream()
                    .filter(item -> !isOfficeSupply(item.getItemName()))
                    .collect(Collectors.toList());
                break;
        }
        
        adapter.updateList(sortedList);
    }

    private boolean isOfficeSupply(String itemName) {
        // Remove any suffix (e.g., " - A") before checking
        String baseName = itemName.split(" - ")[0];
        return officeSupplies.contains(baseName);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SORT_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            currentSort = data.getStringExtra(SortActivity.EXTRA_SORT_TYPE);
            sortInventory();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (LoginActivity.isAdmin) {
            menu.add(Menu.NONE, MENU_GENERATE_TEST_DATA, Menu.NONE, "Generate Test Data")
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == MENU_GENERATE_TEST_DATA) {
            showGenerateTestDataDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showGenerateTestDataDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Generate Test Data")
            .setMessage("This will clear existing inventory and generate test data. Are you sure?")
            .setPositiveButton("Generate", (dialog, which) -> {
                TestDataGenerator generator = new TestDataGenerator(this);
                generator.generateTestData();
                loadInventoryData();
                
                // Log that test data was generated by admin
                logAction("Admin Action", "Generated test data", 0);
                
                Toast.makeText(this, "Test data generated successfully!", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
